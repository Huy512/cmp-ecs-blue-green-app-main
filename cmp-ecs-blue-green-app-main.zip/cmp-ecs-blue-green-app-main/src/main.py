import streamlit as st

st.title("Hello World from CloudMentorPro")
st.title(" deloy ecs blue/green ")
# st.title(" test cicd code pipeline ")
